<?php
	require_once __DIR__ . '/File.php';
	require_once __DIR__ . '/Method.php';
	require_once __DIR__ . '/Response.php';
	require_once __DIR__ . '/Request.php';

	Unirest\Request::VerifyPeer(false);