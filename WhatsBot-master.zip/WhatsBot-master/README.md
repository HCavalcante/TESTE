WhatsBot
========

[![Code Climate](https://codeclimate.com/github/fermino/WhatsBot/badges/gpa.svg)](https://codeclimate.com/github/fermino/WhatsBot) [![Test Coverage](https://codeclimate.com/github/fermino/WhatsBot/badges/coverage.svg)](https://codeclimate.com/github/fermino/WhatsBot)

A module-based, user-friendly whatsapp bot...

Visit our chat at
[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/fermino/WhatsBot)

Visit our [forum](https://whatsbot.org)!

Downloads: 
===================

 * Stable: [v2.0.4b](https://github.com/fermino/WhatsBot/releases/tag/v2.0.4b)
 * Development: [master](https://github.com/fermino/WhatsBot/archive/master.zip)
